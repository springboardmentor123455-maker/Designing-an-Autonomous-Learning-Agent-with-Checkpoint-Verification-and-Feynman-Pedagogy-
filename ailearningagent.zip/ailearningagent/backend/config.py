import os
from dotenv import load_dotenv

load_dotenv()

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
TAVILY_API_KEY = os.getenv("TAVILY_API_KEY", "")

UNDERSTANDING_THRESHOLD = 0.67
CHUNK_SIZE = 1000
CHUNK_OVERLAP = 200

CHECKPOINTS = [
    {
        "id": 1,
        "title": "Machine Learning Fundamentals",
        "objectives": [
            "Understand supervised vs unsupervised learning",
            "Learn common ML algorithms",
            "Grasp the concept of training and testing"
        ]
    },
    {
        "id": 2,
        "title": "Neural Networks Basics",
        "objectives": [
            "Understand neural network architecture",
            "Learn about activation functions",
            "Grasp backpropagation and optimization"
        ]
    },
    {
        "id": 3,
        "title": "Advanced Deep Learning",
        "objectives": [
            "Understand CNNs and RNNs",
            "Learn about attention mechanisms",
            "Grasp transformer architecture"
        ]
    }
]
