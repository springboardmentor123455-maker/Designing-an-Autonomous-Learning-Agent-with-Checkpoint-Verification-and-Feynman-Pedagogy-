from langchain_google_genai import ChatGoogleGenerativeAI, GoogleGenerativeAIEmbeddings
from langchain_community.tools.tavily_search import TavilySearchResults
from langchain_text_splitters import RecursiveCharacterTextSplitter
from pydantic import BaseModel, SecretStr
from typing import Any, Dict, List, Union
import json
from config import GEMINI_API_KEY, TAVILY_API_KEY, UNDERSTANDING_THRESHOLD, CHUNK_SIZE, CHUNK_OVERLAP, CHECKPOINTS

llm = ChatGoogleGenerativeAI(
    model="gemini-pro",
    google_api_key=SecretStr(GEMINI_API_KEY) if GEMINI_API_KEY else None,
    temperature=0.7,
    max_tokens=2048
)

embeddings = GoogleGenerativeAIEmbeddings(
    model="models/embedding-001",
    google_api_key=SecretStr(GEMINI_API_KEY) if GEMINI_API_KEY else None
)

search_tool = TavilySearchResults(
    max_results=5,
    api_key=TAVILY_API_KEY
)

class CheckpointState(BaseModel):
    checkpoint_id: int
    title: str
    objectives: List[str]
    context: str
    questions: List[Dict[str, Any]]
    user_answers: List[str]
    understanding_score: float
    is_passed: bool
    feynman_explanation: str
    attempt_count: int
    completed_checkpoints: List[int]

class LearningAgentState(BaseModel):
    current_checkpoint: CheckpointState
    all_checkpoints: List[Dict[str, Any]]
    session_id: str
    learning_path_complete: bool

def gather_context(checkpoint_id: int, objectives: List[str]) -> str:
    topic = " ".join(objectives)
    search_query = f"comprehensive tutorial on {topic}"

    try:
        results = search_tool.invoke(search_query)
        context = "\n".join([r.get("content", "") for r in results if isinstance(r, dict) and "content" in r])
        return context if context.strip() else get_fallback_context(checkpoint_id)
    except Exception as e:
        return get_fallback_context(checkpoint_id)

def get_fallback_context(checkpoint_id: int) -> str:
    fallback_texts = {
        1: "Machine Learning is the science of programming computers to learn from data without being explicitly programmed. Supervised learning uses labeled training data where each input has a corresponding output. The model learns to map inputs to outputs. Unsupervised learning finds hidden patterns in unlabeled data. Common algorithms include Linear Regression for prediction, Logistic Regression for classification, Decision Trees for interpretable predictions, K-Means for clustering, and Principal Component Analysis for dimensionality reduction.",
        2: "Neural networks consist of interconnected layers of neurons. The input layer receives raw data, hidden layers perform computations, and the output layer produces predictions. Activation functions introduce non-linearity: ReLU (Rectified Linear Unit) for hidden layers, Sigmoid for binary classification, and Tanh for normalized outputs. Backpropagation calculates gradients by working backwards through the network. Optimization algorithms like SGD, Adam, and RMSprop update weights. Epochs represent full passes through training data.",
        3: "Convolutional Neural Networks (CNNs) use convolutional layers to detect local features in images. Pooling layers reduce dimensionality. Recurrent Neural Networks (RNNs) process sequential data by maintaining hidden states. Long Short-Term Memory (LSTM) and Gated Recurrent Units (GRU) solve the vanishing gradient problem. Transformers use self-attention mechanisms to process sequences in parallel. Attention allows the model to focus on relevant parts of input. The Transformer architecture powers modern language models."
    }
    return fallback_texts.get(checkpoint_id, "Learning material unavailable.")

def process_context(raw_context: str) -> str:
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=CHUNK_SIZE,
        chunk_overlap=CHUNK_OVERLAP,
        separators=["\n\n", "\n", " "]
    )
    chunks = splitter.split_text(raw_context)
    return "\n".join(chunks[:5])

def generate_questions(context: str, objectives: List[str]) -> List[Dict[str, Any]]:
    prompt = f"""Create exactly 3 multiple choice questions based on: {', '.join(objectives)}
Context: {context}

Return ONLY this JSON format, no markdown:
{{"questions": [{{"question": "Q1?", "options": ["A", "B", "C", "D"], "correct": "A"}}, {{"question": "Q2?", "options": ["A", "B", "C", "D"], "correct": "B"}}, {{"question": "Q3?", "options": ["A", "B", "C", "D"], "correct": "C"}}]}}"""

    try:
        response = llm.invoke(prompt)
        content = response.content
        if isinstance(content, str):
            content = content.strip()
            if "```" in content:
                content = content.split("```")[1]
                if content.startswith("json"):
                    content = content[4:]
            data = json.loads(content)
            return data.get("questions", [])[:3]
        return get_fallback_questions()
    except:
        return get_fallback_questions()

def get_fallback_questions() -> List[Dict[str, Any]]:
    return [
        {"question": "What is the primary goal of supervised learning?", "options": ["Find patterns", "Use labeled data", "Unsupervised", "No goal"], "correct": "Use labeled data"},
        {"question": "Which activation function introduces non-linearity?", "options": ["Linear", "ReLU", "Sum", "Identity"], "correct": "ReLU"},
        {"question": "What is backpropagation used for?", "options": ["Forward pass", "Calculating gradients", "Prediction", "Data gathering"], "correct": "Calculating gradients"}
    ]

def calculate_score(user_answers: List[str], questions: List[Dict[str, Any]]) -> float:
    if not questions or not user_answers:
        return 0.0

    correct_count = sum(
        1 for i, ans in enumerate(user_answers)
        if i < len(questions) and str(ans).strip().upper() == str(questions[i].get("correct", "")).strip().upper()
    )
    return correct_count / len(questions)

def generate_feynman_explanation(context: str, objectives: List[str], incorrect_concepts: List[str]) -> str:
    prompt = f"""Explain these concepts in SIMPLE everyday language with examples:
Concepts: {', '.join(incorrect_concepts)}
Topics: {', '.join(objectives)}

Use analogies. Avoid jargon. Keep under 150 words. Be clear and friendly."""

    try:
        response = llm.invoke(prompt)
        content = response.content
        if isinstance(content, str):
            return content
        elif isinstance(content, list):
            return " ".join([str(item) for item in content])
        return str(content)
    except:
        return "Let me explain this differently: Think of these concepts as building blocks. Each one helps you understand the bigger picture. Try reviewing the material and focus on the core ideas."

def create_checkpoint_state(checkpoint_id: int, session_id: str) -> CheckpointState:
    checkpoint = next((c for c in CHECKPOINTS if c["id"] == checkpoint_id), CHECKPOINTS[0])

    raw_context = gather_context(checkpoint_id, checkpoint["objectives"])
    processed_context = process_context(raw_context)
    questions = generate_questions(processed_context, checkpoint["objectives"])

    return CheckpointState(
        checkpoint_id=checkpoint_id,
        title=checkpoint["title"],
        objectives=checkpoint["objectives"],
        context=processed_context,
        questions=questions,
        user_answers=[],
        understanding_score=0.0,
        is_passed=False,
        feynman_explanation="",
        attempt_count=0,
        completed_checkpoints=[]
    )
