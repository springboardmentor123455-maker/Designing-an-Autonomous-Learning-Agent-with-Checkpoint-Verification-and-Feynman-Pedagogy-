from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import uuid
from pydantic import BaseModel
from typing import List
from agent import create_checkpoint_state, calculate_score, generate_feynman_explanation
from config import CHECKPOINTS as CONFIG_CHECKPOINTS, UNDERSTANDING_THRESHOLD

app = FastAPI(title="Autonomous Learning Agent")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

sessions = {}

class StartSessionRequest(BaseModel):
    user_name: str

class SubmitAnswersRequest(BaseModel):
    session_id: str
    checkpoint_id: int
    answers: List[str]

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/api/session/start")
def start_session(request: StartSessionRequest):
    session_id = str(uuid.uuid4())
    sessions[session_id] = {
        "user_name": request.user_name,
        "current_checkpoint": 1,
        "completed": [],
        "states": {}
    }

    checkpoint = create_checkpoint_state(1, session_id)
    sessions[session_id]["states"][1] = checkpoint

    return {
        "session_id": session_id,
        "user_name": request.user_name,
        "checkpoint": {
            "id": checkpoint.checkpoint_id,
            "title": checkpoint.title,
            "objectives": checkpoint.objectives,
            "questions": checkpoint.questions,
            "attempt": checkpoint.attempt_count + 1
        }
    }

@app.post("/api/answers/submit")
def submit_answers(request: SubmitAnswersRequest):
    if request.session_id not in sessions:
        raise HTTPException(status_code=404, detail="Session not found")

    session = sessions[request.session_id]
    checkpoint_state = session["states"].get(request.checkpoint_id)

    if not checkpoint_state:
        checkpoint_state = create_checkpoint_state(request.checkpoint_id, request.session_id)
        session["states"][request.checkpoint_id] = checkpoint_state

    checkpoint_state.user_answers = request.answers
    checkpoint_state.attempt_count += 1

    score = calculate_score(request.answers, checkpoint_state.questions)
    checkpoint_state.understanding_score = score

    if score >= UNDERSTANDING_THRESHOLD:
        checkpoint_state.is_passed = True
        session["completed"].append(request.checkpoint_id)

        next_checkpoint_id = request.checkpoint_id + 1
        has_next = any(c["id"] == next_checkpoint_id for c in CONFIG_CHECKPOINTS)

        if has_next:
            next_checkpoint = create_checkpoint_state(next_checkpoint_id, request.session_id)
            session["states"][next_checkpoint_id] = next_checkpoint
            session["current_checkpoint"] = next_checkpoint_id

            return {
                "status": "passed",
                "score": round(score * 100, 1),
                "message": "Perfect! You've passed this checkpoint. Moving to the next level...",
                "next_checkpoint": {
                    "id": next_checkpoint.checkpoint_id,
                    "title": next_checkpoint.title,
                    "objectives": next_checkpoint.objectives,
                    "questions": next_checkpoint.questions,
                    "attempt": 1
                },
                "learning_complete": False
            }
        else:
            return {
                "status": "completed",
                "score": round(score * 100, 1),
                "message": "Congratulations! You've mastered all checkpoints!",
                "learning_complete": True,
                "total_checkpoints": len(CONFIG_CHECKPOINTS),
                "completed": len(session["completed"])
            }
    else:
        feynman_text = generate_feynman_explanation(
            checkpoint_state.context,
            checkpoint_state.objectives,
            ["the main concepts", "key ideas"]
        )
        checkpoint_state.feynman_explanation = feynman_text

        return {
            "status": "failed",
            "score": round(score * 100, 1),
            "message": "Let me explain this in simpler terms...",
            "feynman_explanation": feynman_text,
            "attempt": checkpoint_state.attempt_count,
            "max_attempts": 3,
            "checkpoint_id": request.checkpoint_id,
            "questions": checkpoint_state.questions
        }

@app.get("/api/session/{session_id}/progress")
def get_progress(session_id: str):
    if session_id not in sessions:
        raise HTTPException(status_code=404, detail="Session not found")

    session = sessions[session_id]
    return {
        "user_name": session["user_name"],
        "current_checkpoint": session["current_checkpoint"],
        "completed_checkpoints": session["completed"],
        "total_checkpoints": len(CONFIG_CHECKPOINTS),
        "progress_percentage": round((len(session["completed"]) / len(CONFIG_CHECKPOINTS)) * 100, 1)
    }

@app.get("/api/checkpoints")
def list_checkpoints():
    return {
        "checkpoints": CONFIG_CHECKPOINTS,
        "total": len(CONFIG_CHECKPOINTS)
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=3000)
