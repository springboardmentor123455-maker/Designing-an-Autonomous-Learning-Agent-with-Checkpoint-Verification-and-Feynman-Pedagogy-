# Autonomous Learning Agent

## Overview

This is an AI-powered learning platform that creates personalized, checkpoint-based learning paths. The system uses LangChain with Google's Gemini AI to generate adaptive questions, gather contextual information through web searches, and evaluate student understanding using the Feynman technique. Students progress through structured learning checkpoints (Machine Learning Fundamentals, Neural Networks, Advanced Deep Learning) and must demonstrate mastery through scored assessments before advancing.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Technology Stack**: React 18 with Vite as the build tool

**Design Pattern**: Single-page application (SPA) with component-based architecture

The frontend uses a modern React setup optimized for development speed and hot module replacement (HMR). The Vite configuration is customized for Replit hosting with WebSocket-based HMR using the `REPLIT_DEV_DOMAIN` environment variable for proper tunnel support.

**Rationale**: 
- Vite provides faster development builds compared to traditional webpack setups
- React enables reusable component architecture for checkpoint questions and progress tracking
- The proxy configuration allows seamless communication with the FastAPI backend

**UI Framework**: Custom CSS with design tokens following a comprehensive design system (primitive colors, semantic tokens, background variations)

**State Management**: Local component state with axios for API communication (no global state library detected, suggesting simpler state needs)

### Backend Architecture

**Framework**: FastAPI (Python)

**Design Pattern**: RESTful API with session-based state management

The backend implements an autonomous learning agent using LangChain orchestration. Core responsibilities include:
- Session management for multiple concurrent learners
- Checkpoint state tracking (current position, completion status, attempts)
- Question generation and answer evaluation
- Dynamic context gathering through web search

**Rationale**:
- FastAPI provides automatic API documentation and high performance for Python
- Session-based state (in-memory dictionary) allows quick prototyping without database overhead
- Pydantic models ensure type safety and data validation across the application

**Pros**: Fast development, type-safe, excellent async support
**Cons**: In-memory sessions are lost on restart, no persistence layer, won't scale horizontally

### AI/LLM Integration

**Primary LLM**: Google Gemini Pro (via LangChain)
- Temperature: 0.7 (balanced creativity and consistency)
- Max tokens: 2048
- Used for question generation and answer evaluation

**Embeddings**: Google Generative AI Embeddings (model: embedding-001)
- Purpose: Semantic similarity and understanding assessment

**Web Search Integration**: Tavily Search API
- Max results: 5 per query
- Used to gather real-time contextual information for each checkpoint

**Learning Assessment Strategy**:
- Understanding threshold: 0.67 (67% required to pass)
- Feynman technique for explanation generation
- Attempt tracking per checkpoint
- Progressive checkpoint unlocking

**Rationale**: 
- LangChain provides abstraction over LLM providers, making it easy to swap models
- Gemini Pro offers cost-effective multimodal capabilities
- Tavily provides curated, high-quality search results optimized for AI applications
- The Feynman technique (teaching back) validates deep understanding vs. memorization

### Data Architecture

**Current State**: In-memory session storage (Python dictionary)

**Structure**:
- Sessions indexed by UUID
- Each session contains: user_name, current_checkpoint, completed checkpoints, checkpoint states
- CheckpointState model tracks: questions, answers, scores, attempts, Feynman explanations

**Rationale**: Simplifies initial development and testing without database setup

**Future Consideration**: The architecture will need a persistence layer (database) for production use to maintain session continuity and enable analytics.

### Text Processing

**Strategy**: Recursive Character Text Splitter
- Chunk size: 1000 characters
- Chunk overlap: 200 characters

**Purpose**: Processes large contextual documents from web searches into manageable chunks for LLM processing

### Learning Path Configuration

**Checkpoint System**: Three progressive stages defined in config.py
1. Machine Learning Fundamentals (supervised/unsupervised learning, algorithms, train/test concepts)
2. Neural Networks Basics (architecture, activation functions, backpropagation)
3. Advanced Deep Learning (CNNs, RNNs, attention mechanisms, transformers)

**Rationale**: Structured curriculum ensures foundational knowledge before advanced topics

## External Dependencies

### AI Services
- **Google Gemini API**: Primary LLM for question generation, answer evaluation, and explanations
- **Tavily Search API**: Web search for gathering up-to-date learning materials and context

### Python Backend Dependencies
- **FastAPI**: Web framework for REST API
- **Uvicorn**: ASGI server for FastAPI
- **LangChain**: LLM orchestration framework
  - `langchain-google-genai`: Google Gemini integration
  - `langchain-community`: Community tools including Tavily search
- **Pydantic**: Data validation and settings management
- **python-dotenv**: Environment variable management

### Frontend Dependencies
- **React & ReactDOM**: UI framework (v18.2.0)
- **Axios**: HTTP client for API communication
- **Lucide React**: Icon library for UI elements
- **Vite**: Build tool and dev server

### Configuration Requirements
The application requires two API keys to be set as environment variables:
- `GEMINI_API_KEY`: Google Gemini API access
- `TAVILY_API_KEY`: Tavily Search API access

### Hosting Considerations
- Frontend configured for Replit hosting with custom HMR setup
- CORS enabled for all origins (needs restriction for production)
- Server configured to listen on 0.0.0.0 for container compatibility
- Proxy and WebSocket configuration for Replit's tunnel architecture