import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { CheckCircle2, AlertCircle, Lightbulb, BarChart3, Loader2, Star, Zap, Brain, Target } from 'lucide-react';
import './App.css';

const API_BASE = window.location.hostname.includes('replit')
  ? `${window.location.protocol}//${window.location.hostname.replace(/^[^.]+/, window.location.hostname.split('.')[0].replace(/-00-/, '-3000-'))}/api`
  : `${window.location.protocol}//${window.location.hostname}:3000/api`;

export default function App() {
  const [screen, setScreen] = useState('landing');
  const [userName, setUserName] = useState('');
  const [sessionId, setSessionId] = useState('');
  const [checkpoint, setCheckpoint] = useState(null);
  const [answers, setAnswers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [progress, setProgress] = useState(null);
  const [fadeIn, setFadeIn] = useState(false);

  useEffect(() => {
    setFadeIn(true);
  }, [screen]);

  const startSession = async () => {
    if (!userName.trim()) {
      alert('Please enter your name');
      return;
    }

    setLoading(true);
    try {
      const response = await axios.post(`${API_BASE}/session/start`, { user_name: userName });
      setSessionId(response.data.session_id);
      setCheckpoint(response.data.checkpoint);
      setAnswers(new Array(response.data.checkpoint.questions.length).fill(''));
      setScreen('learning');
      fetchProgress(response.data.session_id);
    } catch (error) {
      alert('Error: ' + error.message);
    }
    setLoading(false);
  };

  const fetchProgress = async (id) => {
    try {
      const response = await axios.get(`${API_BASE}/session/${id}/progress`);
      setProgress(response.data);
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const submitAnswers = async () => {
    if (answers.some(a => !a)) {
      alert('Please answer all questions');
      return;
    }

    setLoading(true);
    try {
      const response = await axios.post(`${API_BASE}/answers/submit`, {
        session_id: sessionId,
        checkpoint_id: checkpoint.id,
        answers: answers
      });

      setResult(response.data);

      if (response.data.status === 'passed') {
        setCheckpoint(response.data.next_checkpoint);
        setAnswers(new Array(response.data.next_checkpoint.questions.length).fill(''));
        setTimeout(() => {
          setResult(null);
          fetchProgress(sessionId);
        }, 2500);
      } else if (response.data.status === 'completed') {
        setTimeout(() => {
          setScreen('completed');
        }, 2500);
      }
    } catch (error) {
      alert('Error: ' + error.message);
    }
    setLoading(false);
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter') {
      startSession();
    }
  };

  if (screen === 'landing') {
    return (
      <div className={`landing ${fadeIn ? 'fade-in' : ''}`}>
        <div className="landing-content">
          <div className="logo-section">
            <Brain size={60} className="logo-icon" />
            <h1>Autonomous Learning Agent</h1>
            <p className="tagline">Developed by Nidhin R  (r.nidhinofficial@gmail.com)</p>
          </div>

          <div className="features-grid">
            <div className="feature-card">
              <Target className="feature-icon" />
              <h3>Structured Path</h3>
              <p>3 progressive checkpoints</p>
            </div>
            <div className="feature-card">
              <Zap className="feature-icon" />
              <h3>Smart Assessment</h3>
              <p>AI-powered evaluation</p>
            </div>
            <div className="feature-card">
              <Lightbulb className="feature-icon" />
              <h3>Feynman Teaching</h3>
              <p>Simplified explanations</p>
            </div>
            <div className="feature-card">
              <BarChart3 className="feature-icon" />
              <h3>Track Progress</h3>
              <p>Visual advancement</p>
            </div>
          </div>

          <div className="input-section">
            <input
              type="text"
              placeholder="Enter your name"
              value={userName}
              onChange={(e) => setUserName(e.target.value)}
              onKeyDown={handleKeyDown}
              disabled={loading}
              className="name-input"
            />
            <button onClick={startSession} disabled={loading} className="start-button">
              {loading ? <Loader2 className="spinner" /> : 'Begin Learning'}
            </button>
          </div>

          <div className="stats-bar">
            <div className="stat"><strong>3</strong> Checkpoints</div>
            <div className="stat"><strong>9</strong> Questions</div>
            <div className="stat"><strong>AI</strong> Based</div>
          </div>

          <div className="developer-credit">
            <p>Developed by <strong>Nidhin R</strong></p>
          </div>
        </div>
      </div>
    );
  }

  if (screen === 'completed') {
    return (
      <div className={`completed-screen ${fadeIn ? 'fade-in' : ''}`}>
        <div className="celebration">
          <div className="stars">
            {[...Array(5)].map((_, i) => <Star key={i} size={40} className="star" />)}
          </div>
          <h1>You're a Master!</h1>
          <p>All checkpoints completed</p>
          <div className="stats">
            <div className="stat-box">
              <h3>{progress?.total_checkpoints || 3}</h3>
              <p>Mastered</p>
            </div>
            <div className="stat-box">
              <h3>100%</h3>
              <p>Complete</p>
            </div>
          </div>
          <button onClick={() => {
            setScreen('landing');
            setUserName('');
            setSessionId('');
            setCheckpoint(null);
            setAnswers([]);
            setResult(null);
          }} className="restart-btn">
            Start New Journey
          </button>
          <div className="developer-credit">
            <p>Developed by <strong>Nidhin R</strong></p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`learning-container ${fadeIn ? 'fade-in' : ''}`}>
      <div className="header-bar">
        <div className="header-left">
          <h2>{checkpoint?.title}</h2>
        </div>
        <div className="header-right">
          <span className="user-name">{userName}</span>
          {progress && <span className="progress-badge">{progress.progress_percentage}%</span>}
        </div>
      </div>

      <div className="learning-content">
        {result && result.status === 'failed' && (
          <div className="feynman-container">
            <div className="feynman-header">
              <Lightbulb className="feynman-icon" />
              <h3>Let Me Explain Simply...</h3>
            </div>
            <div className="feynman-text">{result.feynman_explanation}</div>
            <p className="attempt-info">Attempt {result.attempt} of 3</p>
          </div>
        )}

        {!result && (
          <div className="quiz-section">
            <div className="objectives-box">
              <h4>Today's Goals:</h4>
              <ul>
                {checkpoint?.objectives.map((obj, i) => (
                  <li key={i}>{obj}</li>
                ))}
              </ul>
            </div>

            <div className="questions-container">
              {checkpoint?.questions.map((q, idx) => (
                <div key={idx} className="question-card">
                  <div className="question-number">Q{idx + 1}</div>
                  <h4>{q.question}</h4>
                  <div className="options-grid">
                    {q.options.map((option, optIdx) => (
                      <label key={optIdx} className="option-item">
                        <input
                          type="radio"
                          name={`q${idx}`}
                          value={option}
                          checked={answers[idx] === option}
                          onChange={(e) => {
                            const newAnswers = [...answers];
                            newAnswers[idx] = e.target.value;
                            setAnswers(newAnswers);
                          }}
                          disabled={loading}
                        />
                        <span className={`option-label ${answers[idx] === option ? 'selected' : ''}`}>{option}</span>
                      </label>
                    ))}
                  </div>
                </div>
              ))}
            </div>

            <button onClick={submitAnswers} disabled={loading} className="submit-btn">
              {loading ? <Loader2 className="spinner" /> : 'Check Answers'}
            </button>
          </div>
        )}

        {result && result.status === 'passed' && (
          <div className="success-box">
            <CheckCircle2 size={72} className="success-icon" />
            <h2>Excellent!</h2>
            <p className="score">Score: {result.score}%</p>
            <p className="message">{result.message}</p>
            <Loader2 className="loader" />
          </div>
        )}

        {result && result.status === 'completed' && (
          <div className="success-box">
            <CheckCircle2 size={72} className="success-icon" />
            <h2>Complete!</h2>
            <p className="score">Score: {result.score}%</p>
            <Loader2 className="loader" />
          </div>
        )}
      </div>

      {progress && (
        <div className="progress-container">
          <div className="progress-bar">
            <div className="progress-fill" style={{width: `${progress.progress_percentage}%`}}></div>
          </div>
          <span className="progress-text">{progress.progress_percentage}% Complete</span>
        </div>
      )}
    </div>
  );
}
